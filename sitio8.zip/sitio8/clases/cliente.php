<?php

class Cliente{
    public string $nombre;
    public int $pedidos;
    public bool $activo;

    public function __construct(string $dato, int $compras, bool $activo){
        $this->nombre=$dato;
        $this->pedidos=$compras;
        $this->activo=$activo;


    }

    public function setNombre(string $nombre):void{
        $this->nombre=$nombre;
    }

    public function setPedidos(int $pedidos):void{
        $this->pedido=$pedidos;
    }

    public function setActivo(bool $activo):void{
        $this->activo=$activo;
    }

    public function getNombre(string $nombre):string{
        return $this->nombre;
    }

    public function getPedidos(int $pedidos):int{
        return $this->pedidos;
    }

    public function getActivo(int $activo):bool{
       return $this->activo;
    }


}