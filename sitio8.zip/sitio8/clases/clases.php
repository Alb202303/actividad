<?php
class ClasePropiedades{
    public $nombre="juan";
    public $unidades=15;
    protected $precio=7.95;
    private $descuento=false;
    public int $stock=50;
    public ?string $ciudad="madrid";
}