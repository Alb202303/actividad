<?php

class Productos{
    private string $nombre;
    private int $unidades;
    private float $precio;
    private float $iva=1.21;

    public function __construct(int $id, string $nombre, int $unidades, float $precio){
        $this->id=$id;
        $this->nombre=$nombre;
        $this->unidades=$unidades;
        $this->precio=$precio;



    }
    public function setId(int $id):void{
        $this->id=$id;
    }

    public function setNombre(string $nombre):void{
        $this->nombre=$nombre;
    }

    public function setUnidades(int $unidades):void{
        $this->unidades=$unidades;
    }

    public function setPrecio(float $precio):void{
        $this->precio=$precio;
    }

    public function getId(int $id):int{
        return $this->id;
    }

    public function getNombre(string $nombre):string{
        return $this->nombre;
    }

    public function getUnidades(int $unidades):int{
       return $this->unidades;
    }

    public function getPrecio(int $precio):float{
       return $this->precio;
    }


}

}