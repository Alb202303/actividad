<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>POO en PHP</h2>
    <?php echo "<h3>Clases y objetos</h3>";
    require('./clases/clases.php');
    require('./clases/cliente.php');
    $objeto=new ClasePropiedades();
    echo $objeto->nombre;

    $cliente1=new Cliente("Indra", 5,true);
    echo $cliente1->getNombre();
    //modifica nombre del cliente
    $cliente1->setNombre("Repsol");
    //consulta de nuevo para ver el cambio
    echo $cliente1->getNombre();

    $Producto1=new Producto(100, "Camisa", 5, 7,99);
    echo $Producto1


    ?>
</body>
</html>