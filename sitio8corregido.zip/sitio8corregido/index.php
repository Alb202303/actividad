<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    require('./clase/articulos.php');

    echo phpinfo();

    $articulo= new articulos(100, "camisa", 5, 7.99);
    $articulo->setNombre("Pantalón");
    echo "<p> El nuevo nombre es :".$articulo->getNombre()."</p>";
    echo "<p>El total es: ".$articulo->calcularTotal()."€ </p>";


    ?>
</body>
</html>