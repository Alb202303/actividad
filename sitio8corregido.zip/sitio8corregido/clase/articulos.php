<?php
class Articulos{
    private int $id;
    private string $nombre;
    private int $unidades;
    private float $precio;
    private float $iva=0.21;
    //define("IVA",0.21);

    //Constructor
    public function __construct(int $id, string $nombre, int $unidades, float $precio){
        $this->id=$id;
        $this->nombre=$nombre;
        $this->unidades=$unidades;
        $this->precio=$precio;


    }
    //Getters/setters
    public function setId(int $id):void{
        $this->id=$id;
    }

    public function setNombre(string $nombre):void{
        $this->nombre=$nombre;
    }

    public function setUnidades(int $unidades):void{
        $this->unidades=$unidades;
    }
    public function setPrecio(string $precio):void{
        $this->precio=$precio;
    }

    public function getNombre():string{
        return $this->nombre;
    }

    public function getId():int{
       return $this->id;
    }

    public function getUnidades():int{
        return $this->unidades;
    }
    public function getPrecio():float{
        return $this->precio;
    }

    public function calcularTotal():float{
        $total=$this->unidades*$this->precio*(1+$this->iva);
        return $total;
    }

}